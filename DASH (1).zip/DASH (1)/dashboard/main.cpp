#include <QGuiApplication>
#include <QtQuick>
#include <QtGui/QGuiApplication>
#include <QtQml/QQmlApplicationEngine>
#include <QtGui/QFont>
#include <QtGui/QFontDatabase>
#include "dialog.h"
#include <QApplication>
#include <iostream>
#include <QQmlContext>
#include <QQuickWindow>
#include "masterthread.h"
#include <QQmlProperty>
#include <unistd.h>
#include <sstream>
#include <string>
#include<stdio.h>
#include <stdlib.h>
//#include <QDeclarativeEngine>





int main(int argc, char *argv[])

{
    //QGuiApplication a(argc, argv);


    QApplication a(argc, argv);
    Dialog dialog;
   // dialog.show();
    QQmlEngine engine;
    QQmlComponent component(&engine, (QUrl("qrc:/qml/dashboard.qml")));
    QObject *object = component.create();




        QVariant returnedValue;
    QVariant returnedValuecoms;

    extern quint16 gvolt;
    extern quint16 gtiming;
    extern quint16 grpm;
    extern quint16 gfuel;
    extern quint16 gthrot;
    extern quint16 gtbake;
    extern quint16 ggr2;
    extern quint16 ggr3;
    extern quint16 ggr4;
    extern quint16 ggr5;
    extern quint16 gnitrousen;
    extern quint16 gcambit;
    extern quint16 gmph;
    extern quint16 goilp;
    extern quint16 gwatert;
    extern quint16 gtranst;
    extern quint16 goilt;
    extern quint16 ge1;
    extern quint16 ge2;
    extern quint16 ge3;
    extern quint16 ge4;
    extern quint16 ge5;
    extern quint16 ge6;
    extern quint16 ge7;
    extern quint16 ge8;
    extern quint16 gpr1;
    extern quint16 gpr2;
    extern quint16 gpr3;
    extern quint16 gmap;
    extern quint16 gcamt;
    extern quint16 geaa;
    extern quint16 fire;
    extern quint16 gcbl;
    extern quint16 gttl;
    extern quint16 gttr;
    //quint16 gcoms = 1;
    quint16 bruh = 0;
    extern quint16 gnos1;
    extern quint16 gnos2;
    extern quint16 gnos3;
    extern quint16 gnos4;
    extern quint16 gnos5;
    extern quint16 gnos6;
    extern quint16 gnos7;
    extern quint16 gnos8;
    extern quint16 gnosy;
    quint16 gfunc;

    while(1==1)

    {


        if(returnedValuecoms == 1)
        {
            if(bruh == 0)
            {
                system("sudo /home/aj/hub-ctrl -h 0 -P 2 -p 1");
                bruh = 1;
            }
        }
        if(returnedValuecoms == 0)
        {
            if(bruh == 1)
            {
                system("sudo /home/aj/hub-ctrl -h 0 -P 2 -p 0");
                bruh = 0;
            }
        }

//StartVOLT//////////////////////////////////////
            std::stringstream gvolt1;
            gvolt1 << (gvolt / 100) << "." << ((gvolt % 100) / 10);
            std::string gvolt2 = gvolt1.str();
            QString gvoltstr = QString::fromStdString(gvolt2);

            QMetaObject::invokeMethod(object, "fvolt",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gvoltstr));
//EndVOLT///////////////////////////////////////
//StartRPM//////////////////////////////////////



            QMetaObject::invokeMethod(object, "frpm",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, grpm));

//End RPM/////////
//Start Timing/////////////////////////

            QMetaObject::invokeMethod(object, "ftiming",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gtiming/10));


            QMetaObject::invokeMethod(object, "ffuel",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gfuel));


            QMetaObject::invokeMethod(object, "fthrot",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gthrot));


            QMetaObject::invokeMethod(object, "ftbake",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gtbake));

            QMetaObject::invokeMethod(object, "fgr2",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ggr2));


            QMetaObject::invokeMethod(object, "fgr3",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ggr3));


            QMetaObject::invokeMethod(object, "fgr4",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ggr4));


            QMetaObject::invokeMethod(object, "fgr5",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ggr5));

            QMetaObject::invokeMethod(object, "fcbl",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gcbl));



            QMetaObject::invokeMethod(object, "fnitrousen",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnitrousen));


            QMetaObject::invokeMethod(object, "fcambit",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gcambit));

            QMetaObject::invokeMethod(object, "fmph",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gmph));

            QMetaObject::invokeMethod(object, "foilp",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, goilp));

            QMetaObject::invokeMethod(object, "fwatert",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gwatert));

            QMetaObject::invokeMethod(object, "foilt",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, goilt));

            QMetaObject::invokeMethod(object, "ftranst",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gtranst));

            QMetaObject::invokeMethod(object, "fe1",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ge1));

            QMetaObject::invokeMethod(object, "fe2",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ge2));

            QMetaObject::invokeMethod(object, "fe3",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ge3));

            QMetaObject::invokeMethod(object, "fe4",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ge4));

            QMetaObject::invokeMethod(object, "fe5",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ge5));

            QMetaObject::invokeMethod(object, "fe6",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ge6));

            QMetaObject::invokeMethod(object, "fe7",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ge7));

            QMetaObject::invokeMethod(object, "fe8",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, ge8));

            QMetaObject::invokeMethod(object, "fea",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, geaa));

            QMetaObject::invokeMethod(object, "fpr1",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gpr1));

            QMetaObject::invokeMethod(object, "fpr2",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gpr2));

            QMetaObject::invokeMethod(object, "fpr3",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gpr3));

            QMetaObject::invokeMethod(object, "fmap",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gmap));

            QMetaObject::invokeMethod(object, "fcamt",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gcamt));

            QMetaObject::invokeMethod(object, "fcoms",
            Q_RETURN_ARG(QVariant, returnedValuecoms),
            Q_ARG(QVariant, returnedValuecoms));

            QMetaObject::invokeMethod(object, "ffire",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, fire));

            QMetaObject::invokeMethod(object, "fnos1",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnos1));

            QMetaObject::invokeMethod(object, "fnos2",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnos2));

            QMetaObject::invokeMethod(object, "fnos3",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnos3));

            QMetaObject::invokeMethod(object, "fnos4",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnos4));

            QMetaObject::invokeMethod(object, "fnos5",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnos5));

            QMetaObject::invokeMethod(object, "fnos6",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnos6));

            QMetaObject::invokeMethod(object, "fnos7",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnos7));

            QMetaObject::invokeMethod(object, "fnos8",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnos8));

            QMetaObject::invokeMethod(object, "fnosy",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gnosy));

            QMetaObject::invokeMethod(object, "ffunc",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gfunc));

            QMetaObject::invokeMethod(object, "fttl",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gttl));

            QMetaObject::invokeMethod(object, "fttr",
            Q_RETURN_ARG(QVariant, returnedValue),
            Q_ARG(QVariant, gttr));








    QCoreApplication::processEvents();
}
    return a.exec();
}

//#include "main.moc"
