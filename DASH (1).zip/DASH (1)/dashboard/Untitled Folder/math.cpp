#include "math.h"

math::math()
{

}
