#ifndef MATH_H
#define MATH_H


class math
{
public:
    math();
};

#endif // MATH_H