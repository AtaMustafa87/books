#include <QtGui/QGuiApplication>
#include <QtQml/QQmlApplicationEngine>
#include <QtGui/QFont>
#include <QtGui/QFontDatabase>
//#include <ValueSource.qml>

int main(int argc, char *argv[]) {
     QCoreApplication app(argc, argv);
     QQmlEngine engine;
     Message msg;
     engine.rootContext()->setContextProperty("msg", &volt);
     QQmlComponent component(&engine, QUrl::fromLocalFile("ValueSource.qml"));
     component.create();
     return app.exec();
 }

