/****************************************************************************
** Meta object code from reading C++ file 'serialobd.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../dashboard-obd/serialobd.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'serialobd.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_SerialOBD_t {
    QByteArrayData data[15];
    char stringdata0[150];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SerialOBD_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SerialOBD_t qt_meta_stringdata_SerialOBD = {
    {
QT_MOC_LITERAL(0, 0, 9), // "SerialOBD"
QT_MOC_LITERAL(1, 10, 6), // "obdRPM"
QT_MOC_LITERAL(2, 17, 0), // ""
QT_MOC_LITERAL(3, 18, 3), // "rpm"
QT_MOC_LITERAL(4, 22, 6), // "obdMPH"
QT_MOC_LITERAL(5, 29, 5), // "speed"
QT_MOC_LITERAL(6, 35, 13), // "obdFuelStatus"
QT_MOC_LITERAL(7, 49, 4), // "fuel"
QT_MOC_LITERAL(8, 54, 14), // "obdCoolantTemp"
QT_MOC_LITERAL(9, 69, 11), // "coolantTemp"
QT_MOC_LITERAL(10, 81, 14), // "obdTroubleCode"
QT_MOC_LITERAL(11, 96, 11), // "troublecode"
QT_MOC_LITERAL(12, 108, 11), // "onEngineOff"
QT_MOC_LITERAL(13, 120, 19), // "ConnectToSerialPort"
QT_MOC_LITERAL(14, 140, 9) // "EngineOff"

    },
    "SerialOBD\0obdRPM\0\0rpm\0obdMPH\0speed\0"
    "obdFuelStatus\0fuel\0obdCoolantTemp\0"
    "coolantTemp\0obdTroubleCode\0troublecode\0"
    "onEngineOff\0ConnectToSerialPort\0"
    "EngineOff"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SerialOBD[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x06 /* Public */,
       4,    1,   57,    2, 0x06 /* Public */,
       6,    1,   60,    2, 0x06 /* Public */,
       8,    1,   63,    2, 0x06 /* Public */,
      10,    1,   66,    2, 0x06 /* Public */,
      12,    0,   69,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      13,    0,   70,    2, 0x0a /* Public */,
      14,    0,   71,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::QByteArray,   11,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void SerialOBD::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SerialOBD *_t = static_cast<SerialOBD *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->obdRPM((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->obdMPH((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->obdFuelStatus((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->obdCoolantTemp((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->obdTroubleCode((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 5: _t->onEngineOff(); break;
        case 6: _t->ConnectToSerialPort(); break;
        case 7: _t->EngineOff(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (SerialOBD::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialOBD::obdRPM)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (SerialOBD::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialOBD::obdMPH)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (SerialOBD::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialOBD::obdFuelStatus)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (SerialOBD::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialOBD::obdCoolantTemp)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (SerialOBD::*_t)(QByteArray );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialOBD::obdTroubleCode)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (SerialOBD::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialOBD::onEngineOff)) {
                *result = 5;
                return;
            }
        }
    }
}

const QMetaObject SerialOBD::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_SerialOBD.data,
      qt_meta_data_SerialOBD,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *SerialOBD::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SerialOBD::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_SerialOBD.stringdata0))
        return static_cast<void*>(const_cast< SerialOBD*>(this));
    return QObject::qt_metacast(_clname);
}

int SerialOBD::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void SerialOBD::obdRPM(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SerialOBD::obdMPH(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SerialOBD::obdFuelStatus(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void SerialOBD::obdCoolantTemp(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void SerialOBD::obdTroubleCode(QByteArray _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SerialOBD::onEngineOff()
{
    QMetaObject::activate(this, &staticMetaObject, 5, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
