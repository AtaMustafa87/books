/****************************************************************************
** Meta object code from reading C++ file 'instrumentcluster.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../dashboard-obd/instrumentcluster.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'instrumentcluster.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_InstrumentCluster_t {
    QByteArrayData data[19];
    char stringdata0[175];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InstrumentCluster_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InstrumentCluster_t qt_meta_stringdata_InstrumentCluster = {
    {
QT_MOC_LITERAL(0, 0, 17), // "InstrumentCluster"
QT_MOC_LITERAL(1, 18, 5), // "start"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 6), // "obdRPM"
QT_MOC_LITERAL(4, 32, 3), // "rpm"
QT_MOC_LITERAL(5, 36, 6), // "obdMPH"
QT_MOC_LITERAL(6, 43, 5), // "speed"
QT_MOC_LITERAL(7, 49, 13), // "obdFuelStatus"
QT_MOC_LITERAL(8, 63, 4), // "fuel"
QT_MOC_LITERAL(9, 68, 14), // "obdCoolantTemp"
QT_MOC_LITERAL(10, 83, 11), // "coolantTemp"
QT_MOC_LITERAL(11, 95, 19), // "obdThrottlePosition"
QT_MOC_LITERAL(12, 115, 8), // "throttle"
QT_MOC_LITERAL(13, 124, 14), // "obdTroubleCode"
QT_MOC_LITERAL(14, 139, 11), // "troublecode"
QT_MOC_LITERAL(15, 151, 6), // "gpsLat"
QT_MOC_LITERAL(16, 158, 3), // "Lat"
QT_MOC_LITERAL(17, 162, 7), // "gpsLong"
QT_MOC_LITERAL(18, 170, 4) // "Long"

    },
    "InstrumentCluster\0start\0\0obdRPM\0rpm\0"
    "obdMPH\0speed\0obdFuelStatus\0fuel\0"
    "obdCoolantTemp\0coolantTemp\0"
    "obdThrottlePosition\0throttle\0"
    "obdTroubleCode\0troublecode\0gpsLat\0Lat\0"
    "gpsLong\0Long"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InstrumentCluster[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   59,    2, 0x06 /* Public */,
       3,    1,   60,    2, 0x06 /* Public */,
       5,    1,   63,    2, 0x06 /* Public */,
       7,    1,   66,    2, 0x06 /* Public */,
       9,    1,   69,    2, 0x06 /* Public */,
      11,    1,   72,    2, 0x06 /* Public */,
      13,    1,   75,    2, 0x06 /* Public */,
      15,    1,   78,    2, 0x06 /* Public */,
      17,    1,   81,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::QByteArray,   14,
    QMetaType::Void, QMetaType::Float,   16,
    QMetaType::Void, QMetaType::Float,   18,

       0        // eod
};

void InstrumentCluster::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        InstrumentCluster *_t = static_cast<InstrumentCluster *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->start(); break;
        case 1: _t->obdRPM((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->obdMPH((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->obdFuelStatus((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->obdCoolantTemp((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->obdThrottlePosition((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->obdTroubleCode((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 7: _t->gpsLat((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 8: _t->gpsLong((*reinterpret_cast< float(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (InstrumentCluster::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&InstrumentCluster::start)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (InstrumentCluster::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&InstrumentCluster::obdRPM)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (InstrumentCluster::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&InstrumentCluster::obdMPH)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (InstrumentCluster::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&InstrumentCluster::obdFuelStatus)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (InstrumentCluster::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&InstrumentCluster::obdCoolantTemp)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (InstrumentCluster::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&InstrumentCluster::obdThrottlePosition)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (InstrumentCluster::*_t)(QByteArray );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&InstrumentCluster::obdTroubleCode)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (InstrumentCluster::*_t)(float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&InstrumentCluster::gpsLat)) {
                *result = 7;
                return;
            }
        }
        {
            typedef void (InstrumentCluster::*_t)(float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&InstrumentCluster::gpsLong)) {
                *result = 8;
                return;
            }
        }
    }
}

const QMetaObject InstrumentCluster::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_InstrumentCluster.data,
      qt_meta_data_InstrumentCluster,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *InstrumentCluster::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InstrumentCluster::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_InstrumentCluster.stringdata0))
        return static_cast<void*>(const_cast< InstrumentCluster*>(this));
    return QObject::qt_metacast(_clname);
}

int InstrumentCluster::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void InstrumentCluster::start()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void InstrumentCluster::obdRPM(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void InstrumentCluster::obdMPH(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void InstrumentCluster::obdFuelStatus(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void InstrumentCluster::obdCoolantTemp(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void InstrumentCluster::obdThrottlePosition(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void InstrumentCluster::obdTroubleCode(QByteArray _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void InstrumentCluster::gpsLat(float _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void InstrumentCluster::gpsLong(float _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_END_MOC_NAMESPACE
