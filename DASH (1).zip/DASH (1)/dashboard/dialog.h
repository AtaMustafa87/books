#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QString>
#include "masterthread.h"

//extern quint16 gvolt;

QT_BEGIN_NAMESPACE

class QLabel;
class QLineEdit;
class QSpinBox;
class QPushButton;
class QComboBox;

QT_END_NAMESPACE

class Dialog : public QDialog
{
    Q_OBJECT


public:
    Dialog(QWidget *parent = 0);
   // Q_PROPERTY(Priority priority READ priority WRITE setPriority NOTIFY priorityChanged)

signals:
    //void dvolt(quint16 dvolt);
    //void sendToQml(quint16 dvolt);

private slots:
    void transaction();
    void showResponse(const QByteArray &s);
    void processError(const QString &s);
    void processTimeout(const QString &s);

private:
    void setControlsEnabled(bool enable);

private:
    int transactionCount;
    //int dvolt;
    QLabel *serialPortLabel;
    QComboBox *serialPortComboBox;
    QLabel *waitResponseLabel;
    QSpinBox *waitResponseSpinBox;
    QLabel *requestLabel;
    QLineEdit *requestLineEdit;
    QLabel *trafficLabel;
    QLabel *statusLabel;
    QPushButton *runButton;

    MasterThread thread;


};


#endif // DIALOG_H
