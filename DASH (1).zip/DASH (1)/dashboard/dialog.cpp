
#include "dialog.h"

#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QSpinBox>
#include <QPushButton>
#include <QGridLayout>
#include <QString>
#include <QQmlApplicationEngine>
#include <QQuickWindow>
#include <QQmlContext>
#include <QQmlProperty>
#include <QtSerialPort/QSerialPortInfo>
#include <QApplication>
#include <QQmlProperty>
#include <stdio.h>
#include <iostream>
#include <bitset>

QT_USE_NAMESPACE

quint16 gvolt;
quint16 gtiming;
quint16 grpm;
quint16 gfuel;
quint16 gthrot;
quint16 gtranst;
quint16 goilt;
quint16 gmap;
quint16 gwatert;
quint16 goilp;
quint16 gmph;
quint16 gtbake;
quint16 ggr2;
quint16 ggr3;
quint16 ggr4;
quint16 ggr5;
quint16 gnitrousen;
quint16 gcambit;
quint16 ge1;
quint16 ge2;
quint16 ge3;
quint16 ge4;
quint16 ge5;
quint16 ge6;
quint16 ge7;
quint16 ge8;
quint16 gpr1;
quint16 gpr2;
quint16 gpr3;
quint16 gcamt;
quint16 geaa;
quint16 fire;
quint16 ge1a;
quint16 ge2a;
quint16 ge3a;
quint16 ge4a;
quint16 ge5a;
quint16 ge6a;
quint16 ge7a;
quint16 ge8a;
quint16 gnos1;
quint16 gnos2;
quint16 gnos3;
quint16 gnos4;
quint16 gnos5;
quint16 gnos6;
quint16 gnos7;
quint16 gnos8;
quint16 gnosy;
quint16 gcbl;
quint16 gttl;
quint16 gttr;

//QQmlApplicationEngine engine(QUrl("qrc:/qml/dashboard.qml"));
//QObject *topLevel = engine.rootObjects().value(0);


Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , transactionCount(0)
    , serialPortLabel(new QLabel(tr("Serial port:")))
    , serialPortComboBox(new QComboBox())
    , waitResponseLabel(new QLabel(tr("Wait response, msec:")))
    , waitResponseSpinBox(new QSpinBox())
    , requestLabel(new QLabel(tr("Request:")))
    , requestLineEdit(new QLineEdit(tr("R")))
    , trafficLabel(new QLabel(tr("No traffic.")))
    , statusLabel(new QLabel(tr("Status: Not running.")))
    , runButton(new QPushButton(tr("Start")))
{
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
        serialPortComboBox->addItem(info.portName());

    waitResponseSpinBox->setRange(0, 10000);
    waitResponseSpinBox->setValue(20);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(serialPortLabel, 0, 0);
    mainLayout->addWidget(serialPortComboBox, 0, 1);
    mainLayout->addWidget(waitResponseLabel, 1, 0);
    mainLayout->addWidget(waitResponseSpinBox, 1, 1);
   // mainLayout->addWidget(runButton, 0, 2, 2, 1);
    mainLayout->addWidget(requestLabel, 2, 0);
    mainLayout->addWidget(requestLineEdit, 2, 1, 1, 3);
    mainLayout->addWidget(trafficLabel, 3, 0, 1, 4);
    mainLayout->addWidget(statusLabel, 4, 0, 1, 5);
    setLayout(mainLayout);

    setWindowTitle(tr("COMSYNC Interface"));
    serialPortComboBox->setFocus();

    //connect(runButton, &QPushButton::clicked, this, &Dialog::transaction);
    connect(&thread, &MasterThread::response, this, &Dialog::showResponse);
    //connect(&thread, &MasterThread::response, this, &Dialog::transaction);
    connect(&thread, &MasterThread::error, this, &Dialog::processError);
    connect(&thread, &MasterThread::timeout, this, &Dialog::processTimeout);

    setControlsEnabled(false);
    statusLabel->setText(tr("Status: Running, connected to port %1.")
                         .arg(serialPortComboBox->currentText()));
    thread.transaction(serialPortComboBox->currentText(),
                       waitResponseSpinBox->value(),
                       requestLineEdit->text());
}

void Dialog::transaction()
{
    setControlsEnabled(false);
    statusLabel->setText(tr("Status: Running, connected to port %1.")
                         .arg(serialPortComboBox->currentText()));
    thread.transaction(serialPortComboBox->currentText(),
                       waitResponseSpinBox->value(),
                       requestLineEdit->text());
}

void Dialog::showResponse(const QByteArray &s)
{
    setControlsEnabled(true);



    grpm = (quint8)(s[1]) + (((quint8)(s[0]))<<8);
    gtiming = (quint8)(s[3]) + (((quint8)(s[2]))<<8);
    gtiming &= ~(1U << (10 - 1));
    gtiming &= ~(1U << (11 - 1));
    gtiming &= ~(1U << (12 - 1));
    gtiming &= ~(1U << (13 - 1));
    gtiming &= ~(1U << (14 - 1));
    gtiming &= ~(1U << (15 - 1));

    gttl = (quint8)(s[167]) + (((quint8)(s[166]))<<8);
    gttr = (quint8)(s[169]) + (((quint8)(s[168]))<<8);

    gvolt = (quint8)(s[59]) + (((quint8)(s[58]))<<8);

    //quint16 fueloff = (quint8)(s[261]) + (((quint8)(s[260]))<<8);
    //float fuelmul = ((quint8)(s[277]) + (((quint8)(s[276]))<<8)+(((quint8)(s[279]))<<16) + (((quint8)(s[278]))<<24));
    //float fuellow = ((quint8)(s[253])/100);
    gfuel = (quint8)(s[159]) + (((quint8)(s[158]))<<8);

    gthrot = (quint8)(s[155]) + (((quint8)(s[154]))<<8);
    gmph = ((quint8)(s[163]) + (((quint8)(s[162]))<<8)) /39;
    gtranst = (quint8)(s[69]) + (((quint8)(s[68]))<<8);
    goilt = (quint8)(s[67]) + (((quint8)(s[66]))<<8);
    gmap = (quint8)(s[157]) + (((quint8)(s[156]))<<8);
    goilp = (quint8)(s[31]) + (((quint8)(s[30]))<<8);
    gwatert = (quint8)(s[65]) + (((quint8)(s[64]))<<8);
    gcamt = (quint8)(s[335]);
    quint16 gtbake2 = (quint8)(s[345]) + (((quint8)(s[344]))<<8);
    quint8 gfeat = (quint8)(s[340]);

    fire = (quint8)(s[231]) + (((quint8)(s[230]))<<8);
    fire <<= 1;
    fire >>= 10;

    if (fire == 0){
    ge1a = (quint8)(s[7]) + (((quint8)(s[6]))<<8);
    ge8a = (quint8)(s[9]) + (((quint8)(s[8]))<<8);
    ge4a = (quint8)(s[11]) + (((quint8)(s[10]))<<8);
    ge3a = (quint8)(s[13]) + (((quint8)(s[12]))<<8);
    ge6a = (quint8)(s[15]) + (((quint8)(s[14]))<<8);
    ge5a = (quint8)(s[17]) + (((quint8)(s[16]))<<8);
    ge7a = (quint8)(s[19]) + (((quint8)(s[18]))<<8);
    ge2a = (quint8)(s[21]) + (((quint8)(s[20]))<<8);
    }
    if (fire == 1){
        ge1a = (quint8)(s[7]) + (((quint8)(s[6]))<<8);
        ge8a = (quint8)(s[9]) + (((quint8)(s[8]))<<8);
        ge7a = (quint8)(s[11]) + (((quint8)(s[10]))<<8);
        ge2a = (quint8)(s[13]) + (((quint8)(s[12]))<<8);
        ge6a = (quint8)(s[15]) + (((quint8)(s[14]))<<8);
        ge5a = (quint8)(s[17]) + (((quint8)(s[16]))<<8);
        ge4a = (quint8)(s[19]) + (((quint8)(s[18]))<<8);
        ge3a = (quint8)(s[21]) + (((quint8)(s[20]))<<8);
    }
    if (fire == 2){
        ge1a = (quint8)(s[7]) + (((quint8)(s[6]))<<8);
        ge8a = (quint8)(s[9]) + (((quint8)(s[8]))<<8);
        ge7a = (quint8)(s[11]) + (((quint8)(s[10]))<<8);
        ge3a = (quint8)(s[13]) + (((quint8)(s[12]))<<8);
        ge6a = (quint8)(s[15]) + (((quint8)(s[14]))<<8);
        ge5a = (quint8)(s[17]) + (((quint8)(s[16]))<<8);
        ge4a = (quint8)(s[19]) + (((quint8)(s[18]))<<8);
        ge2a = (quint8)(s[21]) + (((quint8)(s[20]))<<8);
    }
    if (fire == 3){
        ge1a = (quint8)(s[7]) + (((quint8)(s[6]))<<8);
        ge5a = (quint8)(s[9]) + (((quint8)(s[8]))<<8);
        ge4a = (quint8)(s[11]) + (((quint8)(s[10]))<<8);
        ge2a = (quint8)(s[13]) + (((quint8)(s[12]))<<8);
        ge6a = (quint8)(s[15]) + (((quint8)(s[14]))<<8);
        ge3a = (quint8)(s[17]) + (((quint8)(s[16]))<<8);
        ge7a = (quint8)(s[19]) + (((quint8)(s[18]))<<8);
        ge8a = (quint8)(s[21]) + (((quint8)(s[20]))<<8);
    }
    if (fire == 4){
        ge1a = (quint8)(s[7]) + (((quint8)(s[6]))<<8);
        ge3a = (quint8)(s[9]) + (((quint8)(s[8]))<<8);
        ge7a = (quint8)(s[11]) + (((quint8)(s[10]))<<8);
        ge2a = (quint8)(s[13]) + (((quint8)(s[12]))<<8);
        ge6a = (quint8)(s[15]) + (((quint8)(s[14]))<<8);
        ge5a = (quint8)(s[17]) + (((quint8)(s[16]))<<8);
        ge4a = (quint8)(s[19]) + (((quint8)(s[18]))<<8);
        ge8a = (quint8)(s[21]) + (((quint8)(s[20]))<<8);
    }
    if (fire == 5){
        ge1a = (quint8)(s[7]) + (((quint8)(s[6]))<<8);
        ge5a = (quint8)(s[9]) + (((quint8)(s[8]))<<8);
        ge4a = (quint8)(s[11]) + (((quint8)(s[10]))<<8);
        ge8a = (quint8)(s[13]) + (((quint8)(s[12]))<<8);
        ge6a = (quint8)(s[15]) + (((quint8)(s[14]))<<8);
        ge3a = (quint8)(s[17]) + (((quint8)(s[16]))<<8);
        ge7a = (quint8)(s[19]) + (((quint8)(s[18]))<<8);
        ge2a = (quint8)(s[21]) + (((quint8)(s[20]))<<8);
    }


    geaa = (ge1a+ge2a+ge3a+ge4a+ge5a+ge6a+ge7a+ge8a)/8;


    if (ge1a < 1000){ge1=ge1a;
    }
    else{ge1=1000;
    }
    if (ge2a < 1000){ge2=ge2a;
    }
    else{ge2=1000;
    }
    if (ge3a < 1000){ge3=ge3a;
    }
    else{ge3=1000;
    }
    if (ge4a < 1000){ge4=ge4a;
    }
    else{ge4=1000;
    }
    if (ge5a < 1000){ge5=ge5a;
    }
    else{ge5=1000;
    }
    if (ge6a < 1000){ge6=ge6a;
    }
    else{ge6=1000;
    }
    if (ge7a < 1000){ge7=ge7a;
    }
    else{ge7=1000;
    }
    if (ge8a < 1000){ge8=ge8a;
    }
    else{ge8 =1000;
    }

   QByteArray fp;
   float gfuelmul;
   fp[0]=s[278];
   fp[1]=s[279];
   fp[2]=s[276];
   fp[3]=s[277];

   bool okfp;
   int signfp = 1;

    fp = fp.toHex();
    fp = QByteArray::number(fp.toLongLong(&okfp, 16), 2);
    if(fp.length() == 32) {
        if(fp.at(0) == '1') signfp =-1;
            fp.remove(0,1);
    }

        QByteArray fractionfp = fp.right(23);
        double mantissafp = 0;
        for(int i = 0; i < fractionfp.length(); i++){
            if(fractionfp.at(i) == '1')
                mantissafp += 1.0 / (pow(2, i+1));
        }

        int exponentfp = fp.left(fp.length() - 23).toLongLong(&okfp, 2) - 127;
    gfuelmul=(signfp * pow(2, exponentfp) * (mantissafp + 1.0));

    QByteArray op;
    float goilmul;
    op[0]=s[282];
    op[1]=s[283];
    op[2]=s[280];
    op[3]=s[281];

    bool okop;

    int signop = 1;

     op = op.toHex();
     op = QByteArray::number(op.toLongLong(&okop, 16), 2);
     if(op.length() == 32) {
         if(op.at(0) == '1') signop =-1;
             op.remove(0,1);
     }

         QByteArray fractionop = op.right(23);
         double mantissaop = 0;
         for(int i = 0; i < fractionop.length(); i++){
             if(fractionop.at(i) == '1')
                 mantissaop += 1.0 / (pow(2, i+1));
         }

         int exponentop = op.left(op.length() - 23).toLongLong(&okop, 2) - 127;
     goilmul=(signop * pow(2, exponentop) * (mantissaop + 1.0));

     QByteArray map;
     float gmapmul;
     map[0]=s[306];
     map[1]=s[307];
     map[2]=s[304];
     map[3]=s[305];

     bool okmap;
     int signmap = 1;

      map = map.toHex();
      map = QByteArray::number(map.toLongLong(&okmap, 16), 2);
      if(map.length() == 32) {
          if(map.at(0) == '1') signmap =-1;
              map.remove(0,1);
      }

          QByteArray fractionmap = map.right(23);
          double mantissamap = 0;
          for(int i = 0; i < fractionmap.length(); i++){
              if(fractionmap.at(i) == '1')
                  mantissamap += 1.0 / (pow(2, i+1));
          }

          int exponentmap = map.left(map.length() - 23).toLongLong(&okmap, 2) - 127;
      gmapmul=(signmap * pow(2, exponentmap) * (mantissamap + 1.0));

      QByteArray pr1;
      float gpr1mul;
      pr1[0]=s[286];
      pr1[1]=s[287];
      pr1[2]=s[284];
      pr1[3]=s[285];

            bool okpr1;
      int signpr1 = 1;

       pr1 = pr1.toHex();
       pr1 = QByteArray::number(pr1.toLongLong(&okpr1, 16), 2);
       if(pr1.length() == 32) {
           if(pr1.at(0) == '1') signpr1 =-1;
               pr1.remove(0,1);
       }

           QByteArray fractionpr1 = pr1.right(23);
           double mantissapr1 = 0;
           for(int i = 0; i < fractionpr1.length(); i++){
               if(fractionpr1.at(i) == '1')
                   mantissapr1 += 1.0 / (pow(2, i+1));
           }

           int exponentpr1 = pr1.left(pr1.length() - 23).toLongLong(&okpr1, 2) - 127;
       gpr1mul=(signpr1 * pow(2, exponentpr1) * (mantissapr1 + 1.0));

       QByteArray pr2;
       float gpr2mul;
       pr2[0]=s[290];
       pr2[1]=s[291];
       pr2[2]=s[288];
       pr2[3]=s[289];

       bool okpr2;
       int signpr2 = 1;

        pr2 = pr2.toHex();
        pr2 = QByteArray::number(pr2.toLongLong(&okpr2, 16), 2);
        if(pr2.length() == 32) {
            if(pr2.at(0) == '1') signpr2 =-1;
                pr2.remove(0,1);
        }

            QByteArray fractionpr2 = pr2.right(23);
            double mantissapr2 = 0;
            for(int i = 0; i < fractionpr2.length(); i++){
                if(fractionpr2.at(i) == '1')
                    mantissapr2 += 1.0 / (pow(2, i+1));
            }

            int exponentpr2 = pr2.left(pr2.length() - 23).toLongLong(&okpr2, 2) - 127;
        gpr2mul=(signpr2 * pow(2, exponentpr2) * (mantissapr2 + 1.0));

        QByteArray pr3;
        float gpr3mul;
        pr3[0]=s[294];
        pr3[1]=s[295];
        pr3[2]=s[292];
        pr3[3]=s[293];

        bool okpr3;
        int signpr3 = 1;

         pr3 = pr3.toHex();
         pr3 = QByteArray::number(pr3.toLongLong(&okpr3, 16), 2);
         if(pr3.length() == 32) {
             if(pr3.at(0) == '1') signpr3 =-1;
                 pr3.remove(0,1);
         }

             QByteArray fractionpr3 = pr3.right(23);
             double mantissapr3 = 0;
             for(int i = 0; i < fractionpr3.length(); i++){
                 if(fractionpr3.at(i) == '1')
                     mantissapr3 += 1.0 / (pow(2, i+1));
             }

             int exponentpr3 = pr3.left(pr3.length() - 23).toLongLong(&okpr3, 2) - 127;
         gpr3mul=(signpr3 * pow(2, exponentpr3) * (mantissapr3 + 1.0));



     quint16 fpmin = (quint8)(s[253]);
     quint16 opmin = (quint8)(s[252]);
     quint16 mapmin = (quint8)(s[258]);
     quint16 pr1min = (quint8)(s[255]);
     quint16 pr2min = (quint8)(s[254]);
     quint16 pr3min = (quint8)(s[257]);
     quint16 fpoff = (quint8)(s[261]) + (((quint8)(s[260]))<<8);
     quint16 opoff = (quint8)(s[263]) + (((quint8)(s[262]))<<8);
     quint16 mapoff = (quint8)(s[275]) + (((quint8)(s[274]))<<8);
     quint16 pr1off = (quint8)(s[265]) + (((quint8)(s[264]))<<8);
     quint16 pr2off = (quint8)(s[267]) + (((quint8)(s[266]))<<8);
     quint16 pr3off = (quint8)(s[269]) + (((quint8)(s[268]))<<8);
     quint16 fpval = (quint8)(s[159]) + (((quint8)(s[158]))<<8);
     quint16 opval = (quint8)(s[31]) + (((quint8)(s[30]))<<8);
     quint16 mapval = (quint8)(s[157]) + (((quint8)(s[156]))<<8);
     quint16 pr1val = (quint8)(s[35]) + (((quint8)(s[34]))<<8);
     quint16 pr2val = (quint8)(s[37]) + (((quint8)(s[36]))<<8);
     quint16 pr3val = (quint8)(s[39]) + (((quint8)(s[38]))<<8);


     float fpval1;
     float fptemp = (float) (fpmin) / 0.1221 + 0.499;
     if((float)(fpval) > fptemp) fpval1 = ((float)(fpval)-fptemp)*gfuelmul + (float)(fpoff) / 1000 + 0.0499;
     else fpval1 = 0;

     float opval1;
     float optemp = (float) (opmin) / 0.1221 + 0.499;
     if((float)(opval) > optemp) opval1 = ((float)(opval)-optemp)*goilmul + (float)(opoff) / 1000 + 0.0499;
     else opval1 = 0;


     float pr1val1;
     float pr1temp = (float) (pr1min) / 0.1221 + 0.499;
     if((float)(pr1val) > pr1temp) pr1val1 = ((float)(pr1val)-pr1temp)*gpr1mul + (float)(pr1off) / 1000 + 0.0499;
     else pr1val1 = 0;

     float pr2val1;
     float pr2temp = (float) (pr2min) / 0.1221 + 0.499;
     if((float)(pr2val) > pr2temp) pr2val1 = ((float)(pr2val)-pr2temp)*gpr2mul + (float)(pr2off) / 1000 + 0.0499;
     else pr2val1 = 0;

     float pr3val1;
     float pr3temp = (float) (pr3min) / 0.1221 + 0.499;
     if((float)(pr3val) > pr3temp) pr3val1 = ((float)(pr3val)-pr3temp)*gpr3mul + (float)(pr3off) / 1000 + 0.0499;
     else pr3val1 = 0;

     float mapval1;
     float maptemp;

     quint16 gmaptp2 = (quint8)(s[228]);
     gmaptp2 <<= 8;
     gmaptp2 >>= 12;

     if(gmaptp2 == 10)
     {
     maptemp = (float) (mapmin) / 0.1221;
     if((float)(mapval) > maptemp) mapval1 = ((float)(mapval)-maptemp)*gmapmul + (float)(mapoff) / 1000;
     else mapval1 = 0;
     }
     if(gmaptp2 == 1)
     {
     mapval1 = (((float) (mapval) * 0.6809490166)+305.588)/100;
     }
     if(gmaptp2 == 2)
     {
     mapval1 = (((float) (mapval) * 1.44225)+236.741)/100;
     }
     if(gmaptp2 == 3)
     {
     mapval1 = (((float) (mapval) * 2.266976)+33.827)/100;
     }
     if(gmaptp2 == 4)
     {
     mapval1 = (((float) (mapval) * 4.6611722)-1908.75)/100;
     }
     if(gmaptp2 == 5)
     {
     mapval1 = (((float) (mapval) * 4.6611722)-1908.75)/100;
     }
     if(gmaptp2 == 6)
     {
     mapval1 = (((float) (mapval) * 6.21489627)-5090)/100;
     }
     if(gmaptp2 == 15)
     {
     mapval1 = (((float) (mapval) * 1.948986)+1277.476)/100;
     }


     gfuel = (quint16)(fpval1);
     goilp = (quint16)(opval1);
     gmap = (quint16)(mapval1);
     gpr1 = (quint16)(pr1val1);
     gpr2 = (quint16)(pr2val1);
     gpr3 = (quint16)(pr3val1);









    quint16 gtbake1 = (quint8)(s[347]) + (((quint8)(s[346]))<<8);
    if(gtbake1 & std::bitset<32>("0000000000000001").to_ulong())
    {
        gtbake = 1;
    }
    else
    {
        gtbake = 0;
    }

    if(gtbake1 & std::bitset<32>("0000000000000010").to_ulong())
    {
        ggr2 = 1;
    }
    else
    {
        ggr2 = 0;
    }

    if(gtbake1 & std::bitset<32>("0000000000000100").to_ulong())
    {
        ggr3 = 1;
    }
    else
    {
        ggr3 = 0;
    }

    if(gtbake1 & std::bitset<32>("0000000000001000").to_ulong())
    {
        ggr4 = 1;
    }
    else
    {
        ggr4 = 0;
    }

    if(gtbake1 & std::bitset<32>("0000000000010000").to_ulong())
    {
        ggr5 = 1;
    }
    else
    {
        ggr5 = 0;
    }

    if(gtbake1 & std::bitset<32>("0100000000000000").to_ulong())
    {
        gcbl = 1;
    }
    else
    {
        gcbl = 0;
    }

    if(gtbake2 & std::bitset<32>("0000000000010000").to_ulong())
    {
        gcambit = 1;
    }
    else
    {
        gcambit = 0;
    }
    if(gtbake2 & std::bitset<32>("0000000100000000").to_ulong())
    {
        gnos1 = 1;
    }
    else
    {
        gnos1 = 0;
    }
    if(gtbake2 & std::bitset<32>("0000001000000000").to_ulong())
    {
        gnos2 = 1;
    }
    else
    {
        gnos2 = 0;
    }
    if(gtbake2 & std::bitset<32>("0000010000000000").to_ulong())
    {
        gnos3 = 1;
    }
    else
    {
        gnos3 = 0;
    }
    if(gtbake2 & std::bitset<32>("0000100000000000").to_ulong())
    {
        gnos4 = 1;
    }
    else
    {
        gnos4 = 0;
    }
    if(gtbake2 & std::bitset<32>("0001000000000000").to_ulong())
    {
        gnos5 = 1;
    }
    else
    {
        gnos5 = 0;
    }
    if(gtbake2 & std::bitset<32>("0010000000000000").to_ulong())
    {
        gnos6 = 1;
    }
    else
    {
        gnos6 = 0;
    }
    if(gtbake2 & std::bitset<32>("0100000000000000").to_ulong())
    {
        gnos7 = 1;
    }
    else
    {
        gnos7 = 0;
    }
    if(gtbake2 & std::bitset<32>("1000000000000000").to_ulong())
    {
        gnos8 = 1;
    }
    else
    {
        gnos8 = 0;
    }
    if(gfeat & std::bitset<8>("00000010").to_ulong())
    {
        gnosy = 0;
    }
    else
    {
        gnosy = 1;
    }
    if(gtbake2 & std::bitset<32>("0010000000000000").to_ulong())
    {
        gnitrousen = 0;
    }
    else
    {
        gnitrousen = 0;
    }



    trafficLabel->setText(tr("rpm/%1:timing/%2:volt/%3:")
                                                          .arg(grpm).arg(gtiming).arg(gvolt));//).arg(i4).arg(i5).arg(i6).arg(i7).arg(i8).arg(i9));
}

void Dialog::processError(const QString &s)
{
    //setControlsEnabled(true);
   statusLabel->setText(tr("Status: Not running, %1.").arg(s));
    //trafficLabel->setText(tr("No traffic."));
}

void Dialog::processTimeout(const QString &s)
{
   // setControlsEnabled(true);
    statusLabel->setText(tr("Status: Running, %1.").arg(s));
   //trafficLabel->setText(tr("No traffic."));
}

void Dialog::setControlsEnabled(bool enable)
{
    runButton->setEnabled(enable);
    serialPortComboBox->setEnabled(enable);
    waitResponseSpinBox->setEnabled(enable);
    requestLineEdit->setEnabled(enable);
}

